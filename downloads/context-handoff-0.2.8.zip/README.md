# Context Handoff

**Switch AI chats without starting over.**

Capture the loaded text of a ChatGPT, Claude, or Gemini conversation. Review an editable `context.md`, then copy it into your next chat.

## Try the beta

1. Extract the release ZIP into a folder.
2. Open `chrome://extensions` and enable Developer mode.
3. Click **Load unpacked** and select the folder containing `manifest.json`.
4. Open a supported AI conversation and click Context Handoff.
5. Capture, review, choose a destination, and click **Copy & open**. Paste into the new chat.

Chrome 112+ is required. No account or API key is needed for capture or export. **Try a sample handoff** previews the workflow without reading any conversation.

## What ships

- Compact popup with light/dark themes, keyboard focus, and a prominent standalone Copy text button.
- Editable Markdown handoffs with goal, explicit user decisions/requirements, user-specific blockers, references, next actions, and recent turns.
- ChatGPT capture hydrates known turn placeholders, caches messages before they are unmounted, and restores the original scroll position.
- Visible extraction checks and partial-capture disclosure. Captures without readable assistant replies fail rather than creating an empty handoff.
- Clipboard, Markdown, and full captured transcript JSON exports.
- Draft recovery across popup openings using browser-session memory; Clear removes the draft.
- Optional Gemini cleanup with explicit consent, an optional host permission, and your own session-only API key.

No background capture, analytics, accounts, subscriptions, or remote code. The only external request implemented by the extension is optional Gemini cleanup after consent. Opening a destination or copying data remains a user action.

## Development

No runtime dependencies or build step. Edit `popup.html` and `src/`, then reload the extension.

```sh
node tests/handoff.test.mjs
NODE_PATH=/usr/share/nodejs node tests/dom.test.cjs
# Optional rendered smoke test, where headless Chrome is allowed:
node tests/browser.mjs
python3 scripts/package.py
```

The DOM harness uses a development-only jsdom installation (the system jsdom was used here; it is not bundled). The browser checks use an installed Chrome (`CHROME_BIN` can override the path), Node 22+, the Chrome DevTools Protocol, local HTTP, and mocked extension APIs. They do not use personal profiles, API keys, or real chat accounts. Run them in an environment where headless Chrome is supported.

`python3 scripts/icons.py` regenerates the bundled PNG icons with Pillow; Pillow is only needed when editing icons. Packaging needs only Python's standard library. Release ZIPs are deterministic and use an explicit file list. Private owner configuration is unsupported in this public build and excluded.

## Public beta limits

- Extraction depends on third-party page markup and needs real-account testing before a store submission. Version 0.2.1 addresses a real report of UI-only capture but the exact reported live page has not been verified.
- Only loaded text is available. Recognized image/file-only turns are retained as explicit omission markers; image pixels and file contents are not read or transferred. Diagram text labels may be included with a warning that layout and connections are unavailable. Hidden model state, deleted messages, and unloaded turns are not transferred.
- Local handoffs use conservative heuristics, not an LLM. English pattern matching can miss implicit choices or other languages; review the result. Assistant suggestions are not treated as confirmed user decisions.
- Brief/Balanced recent turns and all digest entries are shortened. Detailed preserves the full last eight captured messages. Export JSON to retain all captured message text.
- Changing length rebuilds the draft; edited drafts require confirmation.
- Token counts are rough character-based estimates.
- Browser-session recovery ends when Chrome exits, the extension reloads, updates, or is disabled. Session storage has a size limit; large drafts show a save warning.
- Optional Gemini uses a model ID you can change as Google updates availability. It requires your own key and may incur API charges. It has not been tested against a paid API in this session.
- Copy/open uses the clipboard and opens a fresh tab. Paste manually; no hidden auto-submit or query-string prefill.

See `LAUNCH.md` for launch copy, distribution choices, and remaining store-submission steps; `site/` contains a standalone beta download page and privacy notice.

## Capture troubleshooting in 0.2.2

The supported-tab indicator confirms the URL, not that message extraction will work. The user's live ChatGPT page still failed in 0.2.1 despite passing fixture tests. This release adds a Save diagnostic report button on capture failure to collect structural evidence without conversation text. It does not claim that the live-page issue is fixed. Reload the extension, capture once, then save the report to investigate the actual page layout.

## ChatGPT layout support in 0.2.3

The supplied local diagnostic report confirmed that the failing page uses data-turn-key exchange wrappers, data-conversation-role headings, data-user-message-bubble user payloads, and data-markdown-copy assistant payloads. None of the old author-role/markdown selectors were present. Version 0.2.3 supports this markup, separates both speakers within one exchange, waits for both known roles before marking an exchange recovered, and retains source order when message bodies load separately. The regression suite replays the report's element/attribute topology with synthetic message text. Direct live-browser confirmation is still pending.

## Missing-reply recovery in 0.2.4

The reported export had seven user messages and two assistant replies across seven exchanges. Recovery now scrolls the missing speaker's payload, aligns within nested chat scrollers, and retries multiple positions while preserving earlier captures. A new regression reproduces seven exchanges with only two initially mounted replies and verifies all fourteen messages are recovered when replies mount only after their own bodies enter view. This tests a concrete recovery defect; it is not a live-browser guarantee.

Detailed now preserves the full text of the last eight captured messages. The latest user request leads the goal; an older assistant question is not reused after later user messages; question fragments are not presented as candidate decisions. Partial captures expose Save diagnostic report with per-exchange missing-role and scroll-attempt counters. The old downloaded partial file cannot recover its missing replies without recapture.

## Active-conversation history coverage in 0.2.5

The latest export contained only two readable exchanges while the earlier export had additional, unrelated-looking prompts. Without confirmation of the actual chat contents, the earlier larger count is not ground truth. Version 0.2.5 addresses both whole-exchange virtualization and cross-panel capture: it selects the visible main conversation region, excludes hidden/cached panels, and traverses the actual scroll viewport from top to bottom even when mounted turns already look complete. Messages are retained while DOM windows unmount, and source-order edges preserve chronology when capture starts near the bottom.

Coverage is recorded independently from the number of readable known turns. A blocked, replaced, unmeasurable, stalled, or budget-limited traversal is explicitly unverified in the UI and exported Markdown. Smaller recaptures also retain a coverage warning. The existing history option now enables extra wait time; traversal itself always runs. These checks do not prove hidden server-side history exists or is available.

## Conservative handoff fields in 0.2.6

Decisions, requirements, and blockers now quote explicit user statements with captured-message references. General assistant discussion and recommendations remain in the conversation context. Missing fields say no explicit statement was identified, instead of filling them from broad problem/issue/plan keywords. Recent messages are not duplicated in the earlier digest. Brief/Balanced use excerpts; Detailed retains full recent text; JSON exports all captured messages.

The source includes BETA-CHECK.md for a three-person continuation check. It is a prepared test plan, not a claim of real-user results. Run scripts/package.py before hosting site/ so its current beta download and generated privacy page exist. No runtime dependencies or required API key were added.

## Non-text turns and formulas in 0.2.8

Recognized uploads without typed text retain their role and position as non-text markers. Their presence no longer counts as a failed text load; truly empty turns without attachment evidence remain incomplete. Mixed text/upload turns keep their typed text and disclose the omitted content. If the latest user turn is an upload, the handoff says its contents are unavailable instead of silently presenting an older typed request as the latest one.

KaTeX-style rendering uses a single available TeX annotation; supported MathJax-style accessibility markup uses a single MathML representation. This avoids duplicate visual/accessibility formula layers without deleting legitimately repeated equations. SVG diagrams retain available text labels and an explicit warning that visual structure and connections are missing. There is no OCR, file download, image decoding, or multimodal transfer. Unrecognized or inaccessible visual content can still be omitted.

These cases are covered by synthetic DOM tests. The supplied exam-chat export suggests two upload-only turns, but its live markup has not been inspected and that diagnosis remains unconfirmed. Reload the unpacked extension and refresh the source chat to use this version.


## Launch candidate 0.2.8 — November 19

The continuation instructions now distinguish a request with a following captured assistant reply from a request with no following reply. This is a record of message order, not a claim that the task is complete. Brief and Balanced excerpts preserve complete lines at both ends, mark the omitted middle, and repair code fences around omissions. Long single lines may be omitted entirely; JSON remains the complete captured text. Detailed retains full recent messages.

Public support: ashwajittayade30@gmail.com. See STORE-SUBMISSION.md for the prepared listing and outstanding publication steps.
