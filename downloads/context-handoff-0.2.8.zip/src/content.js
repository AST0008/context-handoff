(() => {
  const VERSION = '0.2.7';
  const CAPTURE = 'CONTEXT_HANDOFF_CAPTURE_V3';
  const PROGRESS = 'CONTEXT_HANDOFF_PROGRESS_V3';
  const installed = window.__contextHandoffCapture;
  if (installed?.version === VERSION) return;
  if (installed?.listener) chrome.runtime.onMessage.removeListener(installed.listener);

  const TURN_SELECTOR = '[data-testid^="conversation-turn-"], [data-turn-id][data-turn], article[data-turn], section[data-turn], [data-turn-key]';
  const ROLE_LABEL_SELECTOR = 'h1[data-conversation-role],h2[data-conversation-role],h3[data-conversation-role],h4[data-conversation-role],h5[data-conversation-role],h6[data-conversation-role]';
  const SCROLL_SELECTOR = '[data-scroll-root], [data-mcp-app-scroll-host], [data-app-action-timeline-scroll]';
  const AUTHOR_SELECTOR = '[data-message-author-role="user"], [data-message-author-role="assistant"]';
  const UI_SELECTOR = 'button, nav, aside, script, style, svg, iframe, textarea, [hidden], [role="toolbar"], [data-testid="ad"], [data-testid="ad-container"], [aria-label="Advertisement"]';
  const ATTACHMENT_SELECTOR = '[data-file-id],[data-testid*="file-attachment"],[data-testid*="uploaded-file"],a[download]';
  const LABEL = /^(?:You said:\s*(?:You)?|ChatGPT said:\s*(?:ChatGPT)?|You|ChatGPT|Claude responded:|Assistant:)$/i;
  const UI_LINE = /^(?:You said:\s*(?:You)?|ChatGPT said:\s*(?:ChatGPT)?|ChatGPT can make mistakes\. Check important info\.|Latest response)$/i;
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  let running = false;
  let lastCaptureDiagnostics = null;
  let activeScope = null;

  function visibleSurface(node) {
    for(let current=node;current;current=current.parentElement) {
      if(current.hidden || current.hasAttribute('inert') || current.getAttribute('aria-hidden')==='true') return false;
      try {
        const style=getComputedStyle(current);
        if(style.display==='none' || style.visibility==='hidden') return false;
      } catch {}
    }
    return true;
  }

  function chooseConversationScope() {
    const surfaces=Array.from(document.querySelectorAll('main,[role="main"]')).filter(visibleSurface);
    const main=surfaces.find(node=>node.hasAttribute('data-app-shell-main-surface')) || surfaces[0];
    if(!main) return null;
    const regions=Array.from(main.querySelectorAll('[data-chatgpt-conversation-selection-target],[data-thread-find-target]')).filter(visibleSurface);
    return regions[0] || main;
  }

  function scope() {
    return activeScope || chooseConversationScope();
  }

  function roots(nodes) {
    const list = Array.from(nodes);
    return list.filter(node => !list.some(other => other !== node && other.contains(node)));
  }

  function ordered(nodes) {
    return nodes.sort((a, b) => a === b ? 0 : a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1);
  }

  function role(node) {
    for (const attr of ['data-message-author-role', 'data-turn', 'data-role', 'data-conversation-role']) {
      const value = node.getAttribute?.(attr);
      if (/^(user|human)$/i.test(value || '')) return 'user';
      if (/^(assistant|model|chatgpt)$/i.test(value || '')) return 'assistant';
    }
    // Role comes from actual accessibility labels, never from turn parity.
    const labels = [...(node.matches?.('h1,h2,h3,h4,h5,h6') ? [node] : []), ...Array.from(node.querySelectorAll?.('h1,h2,h3,h4,h5,h6,[data-message-author]') || [])];
    for (const label of labels) {
      const value = label.textContent.trim();
      if (/^You said:\s*(?:You)?$/i.test(value)) return 'user';
      if (/^ChatGPT said:\s*(?:ChatGPT)?$/i.test(value)) return 'assistant';
    }
    return 'unknown';
  }

  function diagramLabels(node) {
    const parts=Array.from(node.querySelectorAll('title,desc,text,foreignObject')).map(part => text(part).trim()).filter(Boolean);
    return Array.from(new Set(parts));
  }

  function isDiagram(node) {
    if (node.closest('button,nav,[role="toolbar"]')) return false;
    return node.hasAttribute('aria-roledescription') || Boolean(node.closest('.mermaid,[data-diagram],[data-chart-content-reference]')) || node.querySelector('text,foreignObject') !== null;
  }

  function omittedMedia(bodies) {
    const inside=(body,selector)=>[...(body.matches?.(selector)?[body]:[]),...body.querySelectorAll(selector)];
    const images=new Set(),files=new Set(),diagrams=new Set(),embedded=new Set();
    for(const body of bodies) {
      for(const image of inside(body,'img')) {
        if(image.closest('h1,h2,h3,h4,h5,h6,nav,[role="toolbar"],[data-testid*="avatar"]')) continue;
        if(/^(?:avatar|profile|user|assistant|chatgpt)(?:\s+(?:avatar|photo|icon))?$/i.test(image.getAttribute('alt') || '')) continue;
        images.add(image);
      }
      for(const file of roots(inside(body,ATTACHMENT_SELECTOR))) {
        if(!file.querySelector('img')) files.add(file);
      }
      for(const svg of roots(inside(body,'svg'))) if(!svg.closest('mjx-container,.MathJax,.katex') && isDiagram(svg)) diagrams.add(svg);
      for(const media of inside(body,'canvas,iframe,audio,video')) if(!media.closest('button,nav,[role="toolbar"]')) embedded.add(media);
    }
    return [
      ['image',images.size],['file',files.size],['diagram',diagrams.size],['embedded-media',embedded.size]
    ].filter(([,count])=>count>0).map(([kind,count])=>({kind,count,contentsCaptured:false}));
  }

  function text(root) {
    const code = [];
    function preserve(value) {
      const marker = `\u0000HANDOFF_CODE_${code.length}\u0000`;code.push(value);return marker;
    }
    function walk(node) {
      if (node.nodeType === Node.TEXT_NODE) return node.nodeValue || '';
      if (node.nodeType !== Node.ELEMENT_NODE && node.nodeType !== Node.DOCUMENT_FRAGMENT_NODE) return '';
      const tag = node.tagName?.toLowerCase();
      // Rendering layers can repeat the same formula as MathML, TeX, and HTML.
      // Preserve one canonical source and skip the redundant visual children.
      if (node.matches?.('.katex,mjx-container,.MathJax,math')) {
        const annotation=node.querySelector('annotation[encoding="application/x-tex"]');
        if(annotation?.textContent.trim()) {
          const source=annotation.textContent.trim();
          const display=Boolean(node.closest('.katex-display')) || node.getAttribute('display')==='block';
          return display ? `\n\n${preserve(`\\[\n${source}\n\\]`)}\n\n` : preserve(`\\(${source}\\)`);
        }
        const math=node.matches('math')?node:node.querySelector('mjx-assistive-mml math');
        if(math) return `\n\n${preserve('```mathml\n'+new XMLSerializer().serializeToString(math)+'\n```')}\n\n`;
      }
      if(tag==='svg') {
        if(!isDiagram(node)) return '';
        const labels=diagramLabels(node);
        return `\n[Diagram present; visual layout and connections are not captured.${labels.length?' Text labels: '+labels.join(' | '):''}]\n`;
      }
      if (node.matches?.(UI_SELECTOR) || node.matches?.(ATTACHMENT_SELECTOR)) return '';
      if (/^h[1-6]$/.test(tag || '') && LABEL.test(node.textContent.trim())) return '';
      if (tag === 'pre') {
        const body = node.querySelector('code') || node;
        const source = body.textContent || '';
        const language = (body.className || '').match(/language-([\w+-]+)/)?.[1] || '';
        let fence = '```';
        while (source.includes(fence)) fence += '`';
        const marker = `\u0000HANDOFF_CODE_${code.length}\u0000`;
        code.push(`${fence}${language}\n${source}\n${fence}`);
        return `\n\n${marker}\n\n`;
      }
      if (tag === 'br') return '\n';
      const value = Array.from(node.childNodes, walk).join('');
      if (tag === 'li') return `\n- ${value.trim()}\n`;
      if (tag === 'td' || tag === 'th') return `${value}\t`;
      if (/^(p|div|section|article|blockquote|h[1-6]|tr|ul|ol)$/.test(tag || '')) return `\n${value}\n`;
      return value;
    }
    return walk(root).replace(/\n[ \t]+\n/g, '\n\n').replace(/\n{3,}/g, '\n\n')
      .split('\n').filter(line => !UI_LINE.test(line.trim())).join('\n')
      .replace(/\u0000HANDOFF_CODE_(\d+)\u0000/g, (_match, index) => code[Number(index)]).trim();
  }

  function bodyNodes(node, author) {
    const selector = author === 'user'
      ? '[data-user-message-bubble], [data-testid="collapsible-user-message-content"], [data-testid="user-message-content"], .whitespace-pre-wrap'
      : '[data-markdown-copy], .markdown, .prose, [data-testid="assistant-message-content"], [data-message-content]';
    if (node.matches?.(selector)) return [node];
    const matches = roots(node.querySelectorAll(selector));
    return matches.length ? matches : [node];
  }

  function message(node, author, id) {
    const bodies = bodyNodes(node, author);
    const extracted = bodies.map(text).filter(Boolean).join('\n\n');
    // Upload cards may be siblings of the typed-message bubble.
    const omittedContent=omittedMedia([node]);
    const noText=!extracted || UI_LINE.test(extracted) || (bodies[0] === node && LABEL.test(extracted));
    if(noText && !omittedContent.length) return null;
    const content=noText ? '[Non-text turn: '+omittedContent.map(item=>`${item.count} ${item.kind} attachment(s)`).join(', ')+'. Contents were not captured.]' : extracted;
    return {
      id, role: author, content,
      ...(noText?{nonText:true}:{}),
      ...(omittedContent.length?{omittedContent}:{}),
      codeBlocks: bodies.flatMap(body => Array.from(body.querySelectorAll('pre'), pre => ({
        language: (pre.querySelector('code')?.className || '').match(/language-([\w+-]+)/)?.[1] || '',
        content: (pre.querySelector('code') || pre).textContent || ''
      }))),
      links: bodies.flatMap(body => Array.from(body.querySelectorAll('a[href]')).filter(a => !a.closest(ATTACHMENT_SELECTOR) && !a.querySelector('img') && !/^(data|blob):/i.test(a.href)).map(a => ({ text: a.textContent || '', href: a.href })))
    };
  }

  function turnNodes() {
    const root=scope();
    if(!root) return [];
    const turns = roots([...(root.matches(TURN_SELECTOR)?[root]:[]),...root.querySelectorAll(TURN_SELECTOR)]);
    if (turns.length) return ordered(turns);
    const labelled = roots(root.querySelectorAll('article,section')).filter(node => role(node) !== 'unknown');
    if (labelled.length) return ordered(labelled);
    const roleNodes = roots(root.querySelectorAll(AUTHOR_SELECTOR));
    if (roleNodes.length) return ordered(roleNodes);
    return ordered(Array.from(new Set(Array.from(root.querySelectorAll(ROLE_LABEL_SELECTOR), label => label.parentElement))).filter(Boolean));
  }

  function turnKey(node, index) {
    return node.getAttribute('data-turn-key') || node.getAttribute('data-turn-id') || node.getAttribute('data-testid') || node.getAttribute('data-message-id') || `turn-${index}`;
  }

  function labelledMessages(node, key) {
    const labels = Array.from(node.querySelectorAll(ROLE_LABEL_SELECTOR)).filter(label => role(label) !== 'unknown');
    const ordinal = { user: 0, assistant: 0 };
    return labels.map((label, index) => {
      const author = role(label);
      const id = `${key}:${author}:${ordinal[author]++}`;
      const container = label.parentElement;
      const siblings = container.querySelectorAll(ROLE_LABEL_SELECTOR);
      if (siblings.length === 1) {
        const result = message(container, author, id);
        return result ? { ...result, sourceOrder: index } : null;
      }
      // Also support consecutive role headings sharing one wrapper, without
      // mixing the next speaker into the current message.
      const range = document.createRange();
      range.setStartAfter(label);
      if (labels[index + 1]) range.setEndBefore(labels[index + 1]);
      else range.setEnd(node, node.childNodes.length);
      const wrapper = document.createElement('div');
      wrapper.appendChild(range.cloneContents());
      const result = message(wrapper, author, id);
      return result ? { ...result, sourceOrder: index } : null;
    }).filter(Boolean);
  }

  function readTurn(node, key) {
    const authors = node.matches(AUTHOR_SELECTOR) ? [node] : roots(node.querySelectorAll(AUTHOR_SELECTOR));
    if (authors.length) return authors.map((author, i) => message(author, role(author), `${key}:${author.getAttribute('data-message-id') || i}`)).filter(Boolean);
    const labelled = labelledMessages(node, key);
    if (labelled.length) return labelled;
    // A role label may exist before its body hydrates. Never treat its whole
    // exchange as one user message while an assistant placeholder is empty.
    if (node.querySelector(ROLE_LABEL_SELECTOR)) return [];
    const author = role(node);
    return author === 'unknown' ? [] : [message(node, author, `${key}:0`)].filter(Boolean);
  }

  function expectedRoles(node) {
    const authors = node.matches(AUTHOR_SELECTOR) ? [node] : Array.from(node.querySelectorAll(AUTHOR_SELECTOR));
    const labels = Array.from(node.querySelectorAll(ROLE_LABEL_SELECTOR));
    const roles = [...authors, ...labels].map(role).filter(value => value !== 'unknown');
    if (!roles.length && role(node) !== 'unknown') roles.push(role(node));
    return roles;
  }

  function scrollContainers(target = null) {
    const containers = new Set([document.scrollingElement || document.documentElement]);
    document.querySelectorAll(SCROLL_SELECTOR).forEach(node => containers.add(node));
    let node = target || turnNodes()[0] || document.querySelector('main');
    while (node) {
      if (node.scrollHeight > node.clientHeight + 20) {
        try { if (/auto|scroll/.test(getComputedStyle(node).overflowY)) containers.add(node); } catch {}
      }
      node = node.parentElement;
    }
    return Array.from(containers).filter(Boolean);
  }

  function hydrationTarget(node, author) {
    const authors = node.matches(AUTHOR_SELECTOR) ? [node] : Array.from(node.querySelectorAll(AUTHOR_SELECTOR));
    const explicit = authors.find(candidate => role(candidate) === author);
    if (explicit) return bodyNodes(explicit, author)[0] || explicit;
    const label = Array.from(node.querySelectorAll(ROLE_LABEL_SELECTOR)).find(candidate => role(candidate) === author);
    if (label) {
      const container = label.parentElement;
      return bodyNodes(container, author)[0] || container;
    }
    return node;
  }

  function diagnostics() {
    return {
      turnShells: document.querySelectorAll(TURN_SELECTOR).length,
      roleNodes: document.querySelectorAll(AUTHOR_SELECTOR).length,
      assistantBodies: document.querySelectorAll('.markdown,.prose,[data-testid="assistant-message-content"],[data-markdown-copy]').length
    };
  }

  // Structural evidence only: no message text, HTML, attributes containing
  // account/session data, conversation IDs, titles, URLs, or credentials.
  function layoutDiagnostics() {
    const selectors = ['main', '[role="main"]', '#thread', SCROLL_SELECTOR, TURN_SELECTOR, AUTHOR_SELECTOR, ROLE_LABEL_SELECTOR, '[data-user-message-bubble]', '[data-markdown-copy]', '.markdown', '.prose', '[data-testid="collapsible-user-message-content"]'];
    const counts = Object.fromEntries(selectors.map(selector => [selector, document.querySelectorAll(selector).length]));
    const main = scope() || document.querySelector('main,[role="main"],#thread') || document.body;
    const activeScopeCounts = Object.fromEntries(selectors.map(selector => [selector, main.querySelectorAll(selector).length + (main.matches?.(selector) ? 1 : 0)]));
    const outsideScopeCounts = Object.fromEntries(selectors.map(selector => [selector, Math.max(0, counts[selector]-activeScopeCounts[selector]) ]));
    const elements = [main, ...Array.from(main?.querySelectorAll('*') || []).slice(0, 300)];
    const indices = new Map(elements.map((node,index) => [node,index]));
    const safeTestId = value => /^(conversation-turn-\d+|collapsible-user-message-content|user-message|assistant-message|user-message-content|assistant-message-content)$/.test(value || '') ? value : value ? '(other)' : null;
    const tree = elements.filter(node => node && !/^(SCRIPT|STYLE|NOSCRIPT)$/.test(node.tagName)).map(node => {
      let display = { display: 'unavailable', visibility: 'unavailable' };
      try { display = getComputedStyle(node); } catch { /* Diagnostics must not break capture. */ }
      return {
        index: indices.get(node), parent: indices.get(node.parentElement) ?? null,
        tag: node.tagName.toLowerCase(), textChars: (node.textContent || '').length,
        renderedTextChars: typeof node.innerText === 'string' ? node.innerText.length : null,
        testId: safeTestId(node.getAttribute('data-testid')),
        authorRole: /^(user|assistant)$/.test(node.getAttribute('data-message-author-role') || '') ? node.getAttribute('data-message-author-role') : null,
        turnRole: /^(user|assistant)$/.test(node.getAttribute('data-turn') || '') ? node.getAttribute('data-turn') : null,
        headingRole: /^H[1-6]$/.test(node.tagName) ? (/^You said:\s*(?:You)?$/i.test(node.textContent.trim()) ? 'user' : /^ChatGPT said:\s*(?:ChatGPT)?$/i.test(node.textContent.trim()) ? 'assistant' : 'other') : null,
        attributeNames: Array.from(node.attributes, attribute => attribute.name).filter(name => /^(data-|aria-)/.test(name)).slice(0,16),
        classFlags: ['markdown','prose','whitespace-pre-wrap','sr-only','hidden'].filter(name => node.classList.contains(name)),
        hidden: node.hasAttribute('hidden'), display: display.display, visibility: display.visibility
      };
    });
    const shadowRoots = [];
    for (const node of Array.from(document.querySelectorAll('*')).slice(0,4000)) {
      if (node.shadowRoot) shadowRoots.push({ hostTag: node.tagName.toLowerCase(), roleNodes: node.shadowRoot.querySelectorAll(AUTHOR_SELECTOR).length, turnNodes: node.shadowRoot.querySelectorAll(TURN_SELECTOR).length });
    }
    return {
      schemaVersion: 1, extensionVersion: VERSION, createdAt: new Date().toISOString(),
      documentReadyState: document.readyState, counts, activeScopeCounts, outsideScopeCounts, tree, shadowRoots,
      iframeCount: document.querySelectorAll('iframe').length,
      privacy: 'Layout identifiers, counts, visibility, and tags only. No conversation text, HTML, URL, title, cookies, tokens, or keys.'
    };
  }

  function notify(captureId, captured, total) {
    try {
      const sent = chrome.runtime.sendMessage?.({ type: PROGRESS, captureId, captured, total });
      sent?.catch(() => {});
    } catch { /* Closing the popup must not interrupt scroll restoration. */ }
  }

  async function chatgpt(request) {
    const startedAt = Date.now();
    const route = location.pathname;
    const deadline = Date.now() + 60000;
    const savedScroll = scrollContainers().map(node => ({ node, top: node.scrollTop, left: node.scrollLeft }));
    const known = new Map(), captured = new Map(), edges = new Map();
    const historySeen = new Set(), historyTrace = [];
    let recordHistoryOrder = false, lastHistoryKey = null;
    let coverage = {status:'unverified',reason:'history_not_traversed',topReached:false,bottomReached:false};
    let timeLimit = false;
    function connect(before, after) {
      if (before === after) return;
      if (!edges.has(before)) edges.set(before, new Set());
      edges.get(before).add(after);
    }
    function orderedKeys() {
      const degree = new Map(Array.from(known.keys(), key => [key,0]));
      for (const [before, next] of edges) if (known.has(before)) for (const key of next) if (known.has(key)) degree.set(key, degree.get(key)+1);
      const ready = Array.from(known.keys()).filter(key => degree.get(key)===0).sort((a,b) => known.get(a).order-known.get(b).order);
      const result=[];
      while(ready.length) {
        const key=ready.shift();result.push(key);
        for(const after of edges.get(key)||[]) if(degree.has(after)) {
          degree.set(after,degree.get(after)-1);
          if(degree.get(after)===0) ready.push(after);
        }
      }
      if(result.length!==known.size) {
        coverage={...coverage,status:'unverified',reason:'conversation_order_changed'};
        for(const key of known.keys()) if(!result.includes(key)) result.push(key);
      }
      return result;
    }
    function complete(key) {
      const messages = captured.get(key) || [];
      const expected = known.get(key)?.roles || new Set();
      return messages.length > 0 && Array.from(expected).every(author => messages.some(message => message.role === author));
    }
    function recoveredCount() { return Array.from(known.keys()).filter(complete).length; }
    function scan() {
      if (location.pathname !== route || (activeScope && !activeScope.isConnected)) throw new Error('The conversation changed during capture. Open the intended chat and capture again.');
      const snapshot=turnNodes();
      const windowKeys=[];
      snapshot.forEach((node, index) => {
        const key = turnKey(node, index);
        windowKeys.push(key);
        const existing = known.get(key);
        known.set(key, { node, order: existing?.order ?? known.size, attempted: existing?.attempted || false, probes: existing?.probes || [], roles: new Set([...(existing?.roles || []), ...expectedRoles(node)]) });
        const messages = readTurn(node, key);
        if (messages.length) {
          const combined = new Map((captured.get(key) || []).map(message => [message.id, message]));
          messages.forEach(message => combined.set(message.id, message));
          captured.set(key, Array.from(combined.values()).sort((a,b) => (a.sourceOrder ?? 0) - (b.sourceOrder ?? 0)));
        }
      });
      for(let i=1;i<windowKeys.length;i++) connect(windowKeys[i-1],windowKeys[i]);
      if(recordHistoryOrder) for(const key of windowKeys) if(!historySeen.has(key)) {
        if(lastHistoryKey) connect(lastHistoryKey,key);
        historySeen.add(key);lastHistoryKey=key;
      }
      notify(request.captureId, recoveredCount(), known.size);
    }
    function missingRoles(key) {
      const found = captured.get(key) || [];
      return Array.from(known.get(key)?.roles || []).filter(author => !found.some(message => message.role === author));
    }
    function focusMissing(key, alignment) {
      const entry = known.get(key);
      if (!entry) return;
      const author = missingRoles(key)[0] || 'unknown';
      // An exchange can be far taller than the viewport. Bring the missing
      // speaker's payload into view instead of centering the whole exchange.
      const target = hydrationTarget(entry.node, author);
      const scrollers = scrollContainers(target).filter(node => node === target || node.contains(target));
      for (const node of scrollers) {
        if (!savedScroll.some(entry => entry.node === node)) savedScroll.push({node,top:node.scrollTop,left:node.scrollLeft});
      }
      target.scrollIntoView?.({ block: alignment, behavior: 'instant' });
      // Explicitly align within the nested chat scroller as well. Some
      // renderers observe this viewport rather than the document viewport.
      for (const scroller of scrollers) {
        if (!scroller.clientHeight || scroller.scrollHeight <= scroller.clientHeight) continue;
        const viewport = scroller.getBoundingClientRect();
        const box = target.getBoundingClientRect();
        const offset = alignment === 'start' ? 32 : alignment === 'end' ? scroller.clientHeight - Math.min(box.height,scroller.clientHeight) - 32 : (scroller.clientHeight - Math.min(box.height,scroller.clientHeight)) / 2;
        scroller.scrollTop += box.top - viewport.top - offset;
      }
      if (entry.probes.length < 12) entry.probes.push({ role: author, alignment, targetTag: target.tagName.toLowerCase(), connected: target.isConnected, targetTextChars: (target.textContent || '').length });
    }
    function rememberScroll(node) {
      if(!savedScroll.some(entry=>entry.node===node)) savedScroll.push({node,top:node.scrollTop,left:node.scrollLeft});
    }
    function chooseHistoryViewport() {
      const anchor=turnNodes()[0] || document.querySelector('main');
      const candidates=scrollContainers(anchor).filter(node=>node && (!anchor || node.contains(anchor)) && node.clientHeight>=80 && node.scrollHeight>node.clientHeight+8);
      // Prefer the innermost real scrolling ancestor of the conversation.
      candidates.sort((a,b)=>a===b?0:a.contains(b)?1:b.contains(a)?-1:0);
      for(const node of candidates) {
        rememberScroll(node);
        const previous=node.scrollTop;
        const maximum=node.scrollHeight-node.clientHeight;
        node.scrollTop=previous<maximum-2?previous+2:Math.max(0,previous-2);
        const changed=Math.abs(node.scrollTop-previous)>0.5;
        node.scrollTop=previous;
        if(changed) return node;
      }
      return null;
    }
    async function sweepHistory() {
      const viewport=chooseHistoryViewport();
      if(!viewport) {
        coverage={status:'unverified',reason:'no_measurable_history_viewport',topReached:false,bottomReached:false};
        return;
      }
      const wait=request.loadOlderTurns?350:200;
      const sweepDeadline=Math.min(deadline-8000,startedAt+45000);
      let topStable=0,previousHeight=-1;
      for(let attempt=0;attempt<6 && Date.now()<sweepDeadline;attempt++) {
        viewport.scrollTop=0;
        await sleep(wait);scan();
        const height=viewport.scrollHeight;
        topStable=height===previousHeight?topStable+1:0;
        previousHeight=height;
        if(viewport.scrollTop<=4 && topStable>=2) break;
      }
      coverage={status:'unverified',reason:'history_traversal_incomplete',topReached:viewport.scrollTop<=4 && topStable>=2,bottomReached:false};
      recordHistoryOrder=true;
      let bottomStable=0,stalled=0,previousBottomHeight=-1;
      for(let step=0;step<160 && Date.now()<sweepDeadline;step++) {
        if(!viewport.isConnected) {coverage.reason='history_viewport_replaced';break;}
        scan();
        const maximum=Math.max(0,viewport.scrollHeight-viewport.clientHeight);
        const position=viewport.scrollTop;
        if(historyTrace.length<160) historyTrace.push({position,scrollHeight:viewport.scrollHeight,viewportHeight:viewport.clientHeight,knownTurns:known.size,recoveredTurns:recoveredCount()});
        if(position>=maximum-4) {
          bottomStable=viewport.scrollHeight===previousBottomHeight?bottomStable+1:0;
          previousBottomHeight=viewport.scrollHeight;
          if(bottomStable>=2) {coverage.bottomReached=true;break;}
          await sleep(wait);continue;
        }
        bottomStable=0;
        viewport.scrollTop=Math.min(maximum,position+Math.max(80,viewport.clientHeight*0.6));
        await sleep(wait);scan();
        stalled=viewport.scrollTop<=position+1?stalled+1:0;
        if(stalled>=3) {coverage.reason='history_scroller_did_not_advance';break;}
      }
      recordHistoryOrder=false;
      coverage.visitedPositions=historyTrace.length;
      if(coverage.topReached && coverage.bottomReached) {coverage.status='traversed';coverage.reason='viewport_boundaries_reached';}
      else if(Date.now()>=sweepDeadline) coverage.reason='history_time_limit';
    }
    try {
      scan();
      // Always discover complete turn windows, even if all currently mounted
      // turns look complete. Mounted DOM counts are not conversation length.
      await sweepHistory();
      for (;;) {
        scan();
        const pending = Array.from(known).find(([key, value]) => !complete(key) && !value.attempted);
        if (!pending) break;
        if (Date.now() >= deadline) { timeLimit = true; break; }
        const [key, entry] = pending;
        entry.attempted = true;
        // Retarget after rerenders, and try multiple positions for large bodies.
        // Cache every readable neighbour before the next scroll unmounts it.
        for (let poll = 0; poll < 24; poll++) {
          if ([0,6,12,18].includes(poll)) focusMissing(key, poll === 0 ? 'start' : poll === 12 ? 'end' : 'center');
          await sleep(125);
          scan();
          const current = known.get(key);
          if (current) current.attempted = true;
          if (complete(key) || Date.now() >= deadline) break;
        }
      }
      const missing = {user:0,assistant:0};
      for (const key of known.keys()) for (const author of missingRoles(key)) if (author in missing) missing[author]++;
      const chronological=orderedKeys();
      lastCaptureDiagnostics = { elapsedMs: Date.now() - startedAt, timeLimit, coverage, historyTrace, turns: Array.from(known.entries(), ([key,entry]) => ({ order: entry.order, expectedRoles: Array.from(entry.roles), recoveredRoles: (captured.get(key) || []).map(message => message.role), nonTextRoles: (captured.get(key) || []).filter(message => message.nonText).map(message => message.role), omittedKinds: Array.from(new Set((captured.get(key) || []).flatMap(message => (message.omittedContent || []).map(item => item.kind)))), missingRoles: missingRoles(key), complete: complete(key), probes: entry.probes })) };
      const messages = chronological.flatMap(key => captured.get(key) || []);
      return { messages, extraction: {
        version: VERSION, strategy: 'chatgpt-history-sweep', scope: 'active-conversation', coverage, expectedTurnCount: known.size,
        capturedTurnCount: recoveredCount(), missingTurnCount: known.size - recoveredCount(),
        missingUserMessageCount: missing.user, missingAssistantMessageCount: missing.assistant,
        timeLimit, diagnostics: diagnostics()
      }};
    } finally {
      for (const {node,top,left} of savedScroll) { node.scrollTop = top; node.scrollLeft = left; }
    }
  }

  function otherPlatform(source) {
    const selectors = source === 'claude'
      ? [['[data-testid="user-message"]','user'], ['[data-testid="assistant-message"], .font-claude-message','assistant']]
      : [['user-query, [data-test-id="user-query"], [data-testid="user-query"], .user-query','user'], ['model-response, [data-test-id="model-response"], [data-testid="model-response"], .model-response','assistant']];
    const entries = selectors.flatMap(([selector, author]) => roots((scope() || document.createElement('div')).querySelectorAll(selector)).map(node => ({node,author})));
    entries.sort((a,b) => a.node.compareDocumentPosition(b.node) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1);
    return { messages: entries.map(({node,author},i) => message(node,author,`${source}-${i}`)).filter(Boolean), extraction: { version: VERSION, strategy: `${source}-messages` } };
  }

  async function capture(request) {
    lastCaptureDiagnostics = null;
    activeScope = chooseConversationScope();
    const source = location.hostname === 'claude.ai' ? 'claude' : location.hostname === 'gemini.google.com' ? 'gemini' : 'chatgpt';
    const result = source === 'chatgpt' ? await chatgpt(request) : otherPlatform(source);
    const url = new URL(location.href); url.search = ''; url.hash = '';
    return {
      schemaVersion: 1, platform: source,
      title: document.title.replace(/\s*[-|]\s*(ChatGPT|Claude|Gemini)$/i, '').trim() || 'Untitled chat',
      url: url.href, capturedAt: new Date().toISOString(), messageCount: result.messages.length,
      ...result
    };
  }

  const listener = (request, _sender, sendResponse) => {
    if (request?.type !== CAPTURE) return false;
    if (running) { sendResponse({ ok: false, error: 'A capture is already running. Wait for it to finish.' }); return false; }
    running = true;
    (async () => {
      try {
        const transcript = await capture(request);
        let diagnosticReport = null;
        try { diagnosticReport = layoutDiagnostics(); if (lastCaptureDiagnostics) diagnosticReport.capture = lastCaptureDiagnostics; } catch { /* Keep successful captures usable. */ }
        sendResponse({ ok: true, transcript, diagnosticReport });
      }
      catch (error) { sendResponse({ ok: false, error: error.message || 'Could not read the conversation.' }); }
      finally { running = false; }
    })();
    return true;
  };
  chrome.runtime.onMessage.addListener(listener);
  window.__contextHandoffCapture = { version: VERSION, listener };
})();
