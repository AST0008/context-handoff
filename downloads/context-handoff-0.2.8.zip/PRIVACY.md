# Context Handoff privacy notice

Last updated: November 19, 2026. Applies to version 0.2.8.

## What is read

Only when you click Capture, Context Handoff reads the loaded text of the active ChatGPT, Claude, or Gemini conversation. It includes message text, code, links, title, and conversation URL. ChatGPT capture is restricted to the visible main conversation region. It temporarily scans its scroll viewport from top to bottom to discover message windows, caches readable turns, and restores the original scroll positions. An option adds extra waiting time for slow-loading history. Counts of known, recovered, and missing turns are retained with the capture; ordinary handoff exports do not include page layout or account metadata beyond the stated conversation fields. It does not read cookies, credentials, private account APIs, other tabs, or background browsing history. Conversation text may itself contain personal information; review it before exporting.

Recognized attachments are represented only by presence/type counts and omission markers. The extension does not download, decode, OCR, or transfer image pixels or file contents. Available formula source text (TeX or MathML) and diagram text labels can be read from message markup; diagram layout and connections are not reconstructed. These text representations and omission markers are included in the captured transcript and handoff. Attachment URLs and file-card names are excluded by the recognized attachment handling.

## Where it stays

The captured transcript and edited handoff are kept in Chrome's extension session storage so reopening the popup does not lose your work. This memory is cleared when Chrome exits or the extension reloads, updates, or is disabled. Click Clear to remove the draft immediately. Drafts are not synced or uploaded automatically. Capture preferences and the optional Gemini model ID stay in local extension settings. A Gemini API key, if supplied, is kept only in trusted extension session storage, not in persistent settings or source files.

## Copy, download, and continue

Copy writes the edited handoff to the operating system clipboard. Download saves a local file. Copy & open copies the handoff and opens the selected AI website; paste is manual. Conversation text is never embedded in the destination URL. Your clipboard, downloaded files, and destination chat service have their own retention behavior, beyond this extension's Clear button.

## Optional Gemini cleanup

No data is sent for cleanup by default. To request it, provide your own key, select the consent checkbox, click Send to Gemini & clean up, and grant Chrome's optional Google API host permission. That action sends the captured transcript (up to 60,000 characters of serialized text, with up to 4,000 characters per turn) and current handoff to Google's Gemini API over HTTPS. The current handoff itself is sent in full. Google processes the request under the terms for your API account; API charges may apply. The extension does not control Google's retention or use of that content. Consent is reset when the draft changes. Forget saved key & revoke access removes the session key and optional permission.

## Other data sharing

This build contains no advertising, analytics, tracking SDK, accounts, or hosted application backend. The creator does not receive your conversation or API key through this extension. No data is sold. Reading this public beta's website does not send chat data from the extension; a deployment host may process ordinary web request logs under its own terms.

## Contact

Support and privacy questions: ashwajittayade30@gmail.com.

## Optional local diagnostic report

If capture fails, Save diagnostic report downloads a JSON file with selector counts, element tags, known role labels, visibility, limited known class/attribute identifiers, counts of open shadow roots and iframes, and per-exchange expected/recovered roles, non-text role/type counts, traversal coverage, scroll positions and structural scroll-attempt counters, and counts of matching nodes inside/outside the selected conversation region. Capture counters may remain in the active tab until the next capture or page reload. It contains no conversation text, raw HTML, page title, conversation URL/ID, attribute values outside a fixed safe label list, cookies, tokens, or API keys. The report is held in popup memory until you choose to save it; it is not uploaded, synced, automatically downloaded, or saved in the handoff session. Share the local file with the developer only if you choose.
